<!DOCTYPE html>
<html lang="zh-CN">
<body>

</div> <!-- content End -->
<?php
include_once 'ajax.php';

?>
<!-- Footer Start -->
<footer class="footer">
    <div class="row footer_center">
        <div class="col-md-6">
            Copyright © 2022-<?php echo date("Y")  ?> <a href="https://blog.kikiw.cn/index.php/archives/52/" target="_blank">Ki</a> All Rights
            Reserved.
        </div>
    </div>
</footer>
<!-- end Footer -->
</div>

<!-- content-page -->

</div>
<!-- Wap END -->

</div>
<!-- Mian END -->

<script>
    console.log("%c Like Girl v5.2.0 | Powered by Ki", "color:#fff;background:linear-gradient(270deg,#986fee,#8695e6,#68b7dd,#18d7d3);padding:8px 15px;border-radius:15px");
    console.log("%c Q | 3439780232", "color:#fff;background:#000;padding:8px 15px;border-radius:15px");
    
</script>


<script src="../Style/toastr/toastr.js"></script>
<!-- App js -->
<script src="/admin/assets/js/app.min.js"></script>

<!-- end demo js-->
<script src="/admin/assets/js/pages/demo.toastr.js"></script>

</body>

</html>